import { useState, useRef, useEffect } from 'react'
import { Play, Pause, Volume2, VolumeX, Maximize, X, Check, SkipForward } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

export default function StreamPlayer({ video, onClose, onComplete, isCompleted, autoPlay = false }) {
  const videoRef = useRef(null)
  const [playbackState, setPlaybackState] = useState({
    playing: autoPlay,
    muted: false,
    time: 0,
    duration: 0,
    ended: false
  })
  const [uiState, setUiState] = useState({
    controlsVisible: true,
    fullscreen: false
  })

  const controlsTimeout = useRef(null)

  useEffect(() => {
    const el = videoRef.current
    if (!el) return

    const handlers = {
      timeUpdate: () => setPlaybackState(p => ({ ...p, time: el.currentTime })),
      loadedMetadata: () => setPlaybackState(p => ({ ...p, duration: el.duration })),
      ended: () => {
        setPlaybackState(p => ({ ...p, ended: true, playing: false }))
        if (onComplete && !isCompleted) setTimeout(onComplete, 500)
      }
    }

    el.addEventListener('timeupdate', handlers.timeUpdate)
    el.addEventListener('loadedmetadata', handlers.loadedMetadata)
    el.addEventListener('ended', handlers.ended)

    if (autoPlay) el.play().catch(() => { })

    return () => {
      el.removeEventListener('timeupdate', handlers.timeUpdate)
      el.removeEventListener('loadedmetadata', handlers.loadedMetadata)
      el.removeEventListener('ended', handlers.ended)
    }
  }, [autoPlay, onComplete, isCompleted])

  useEffect(() => {
    const el = videoRef.current
    if (!el) return
    playbackState.playing ? el.play().catch(() => { }) : el.pause()
    el.muted = playbackState.muted
  }, [playbackState.playing, playbackState.muted])

  const handleInteraction = () => {
    setUiState(p => ({ ...p, controlsVisible: true }))
    if (controlsTimeout.current) clearTimeout(controlsTimeout.current)
    controlsTimeout.current = setTimeout(() => {
      if (playbackState.playing) setUiState(p => ({ ...p, controlsVisible: false }))
    }, 2500)
  }

  const togglePlay = () => {
    setPlaybackState(p => ({ ...p, playing: !p.playing }))
    handleInteraction()
  }

  const seek = (e) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const pct = (e.clientX - rect.left) / rect.width
    if (videoRef.current) videoRef.current.currentTime = pct * playbackState.duration
    handleInteraction()
  }

  const formatTime = (s) => {
    if (!s) return '0:00'
    const m = Math.floor(s / 60)
    const sec = Math.floor(s % 60)
    return `${m}:${sec.toString().padStart(2, '0')}`
  }

  if (!video?.videoUrl) return null

  return (
    <div className="fixed inset-0 bg-surface-900/95 z-[100] flex items-center justify-center p-4 sm:p-8 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-6xl bg-black rounded-2xl overflow-hidden shadow-2xl relative aspect-video group"
        onMouseMove={handleInteraction}
        onMouseLeave={() => playbackState.playing && setUiState(p => ({ ...p, controlsVisible: false }))}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 z-50 p-2 bg-black/50 hover:bg-surface-800 text-white rounded-full transition-all backdrop-blur-md"
        >
          <X className="w-5 h-5" />
        </button>

        <video
          ref={videoRef}
          src={video.videoUrl}
          className="w-full h-full object-contain"
          onClick={togglePlay}
          playsInline
        />

        {/* Completion State */}
        <AnimatePresence>
          {playbackState.ended && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center z-40"
            >
              <motion.div
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mb-6"
              >
                <Check className="w-10 h-10 text-green-500" />
              </motion.div>
              <h2 className="text-3xl font-bold text-white mb-2">Session Complete</h2>
              <p className="text-surface-400 mb-8">You've finished watching "{video.title}"</p>
              <button
                onClick={onClose}
                className="px-8 py-3 bg-primary-600 hover:bg-primary-500 text-white rounded-xl font-semibold transition-colors"
              >
                Return to Course
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Controls */}
        <AnimatePresence>
          {uiState.controlsVisible && !playbackState.ended && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent pointer-events-none flex flex-col justify-end"
            >
              {/* Center Play Button */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-auto">
                <button
                  onClick={togglePlay}
                  className="w-24 h-24 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center transition-all transform hover:scale-105"
                >
                  {playbackState.playing ? (
                    <Pause className="w-10 h-10 text-white fill-current" />
                  ) : (
                    <Play className="w-10 h-10 text-white fill-current ml-1" />
                  )}
                </button>
              </div>

              {/* Bottom Bar */}
              <div className="p-8 pointer-events-auto space-y-4">
                {/* Progress */}
                <div className="h-1.5 bg-white/20 rounded-full cursor-pointer group" onClick={seek}>
                  <div
                    className="h-full bg-primary-500 rounded-full relative"
                    style={{ width: `${(playbackState.time / playbackState.duration) * 100}%` }}
                  >
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <button onClick={togglePlay} className="text-white hover:text-primary-400 transition-colors">
                      {playbackState.playing ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                    </button>

                    <button onClick={() => setPlaybackState(p => ({ ...p, muted: !p.muted }))} className="text-white hover:text-primary-400 transition-colors">
                      {playbackState.muted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
                    </button>

                    <span className="text-sm font-medium text-surface-300">
                      {formatTime(playbackState.time)} / {formatTime(playbackState.duration)}
                    </span>
                  </div>

                  <div className="flex items-center gap-4">
                    {isCompleted && (
                      <span className="flex items-center gap-2 text-green-400 text-sm font-medium bg-green-400/10 px-3 py-1 rounded-full">
                        <Check className="w-4 h-4" /> Watched
                      </span>
                    )}
                    <button onClick={() => videoRef.current?.requestFullscreen()} className="text-white hover:text-primary-400 transition-colors">
                      <Maximize className="w-6 h-6" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  )
}
