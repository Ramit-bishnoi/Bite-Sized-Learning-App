import { useState } from 'react'
import { motion } from 'framer-motion'
import { Play, Heart, MessageSquare, Clock, Eye } from 'lucide-react'

export default function MediaPreview({ video, onLike, onView }) {
  const [isHovered, setIsHovered] = useState(false)
  const [isLiked, setIsLiked] = useState(video.liked || false)

  const handleLikeInteraction = (e) => {
    e.stopPropagation()
    setIsLiked(!isLiked)
    if (onLike) onLike()
  }

  return (
    <div
      className="group relative bg-surface-800 rounded-xl overflow-hidden border border-surface-700 hover:border-primary-500/30 transition-all cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-primary-900/20"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onView}
    >
      {/* Thumbnail Section */}
      <div className="relative aspect-[9/16] overflow-hidden">
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/80" />

        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-14 h-14 bg-primary-600/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-xl transform scale-90 group-hover:scale-100 transition-transform">
            <Play className="w-6 h-6 text-white ml-1" fill="currentColor" />
          </div>
        </div>

        {/* Top Badges */}
        <div className="absolute top-3 right-3">
          <span className="px-2 py-1 bg-black/60 backdrop-blur-md rounded text-xs font-medium text-white flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {video.duration}s
          </span>
        </div>
      </div>

      {/* Info Section */}
      <div className="p-4">
        <h4 className="font-bold text-white text-base mb-1 line-clamp-1 group-hover:text-primary-400 transition-colors">
          {video.title}
        </h4>
        <p className="text-surface-400 text-xs mb-4 line-clamp-2">
          {video.description}
        </p>

        {/* Interactive Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-surface-700/50">
          <div className="flex items-center gap-4">
            <button
              onClick={handleLikeInteraction}
              className={`flex items-center gap-1.5 text-xs font-medium transition-colors ${isLiked ? 'text-secondary-500' : 'text-surface-400 hover:text-secondary-500'
                }`}
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
              <span>{video.likes || 0}</span>
            </button>

            <div className="flex items-center gap-1.5 text-xs font-medium text-surface-400">
              <MessageSquare className="w-4 h-4" />
              <span>{video.comments?.length || 0}</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-surface-500">
            <Eye className="w-3 h-3" />
            <span>{video.views || 0}</span>
          </div>
        </div>
      </div>
    </div>
  )
}
