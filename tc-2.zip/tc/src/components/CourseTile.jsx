import { Link } from 'react-router-dom'
import { BookOpen, Play, TrendingUp, Star } from 'lucide-react'

export default function CourseTile({ course }) {
  return (
    <Link to={`/learn/${course.id}`} className="block group">
      <div className="relative bg-surface-800 rounded-xl overflow-hidden border border-surface-700 hover:border-primary-500/50 hover:shadow-xl hover:shadow-primary-500/10 transition-all duration-300">
        {/* Image Container */}
        <div className="aspect-[4/3] relative overflow-hidden">
          <img
            src={course.thumbnail}
            alt={course.title}
            className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-surface-900/90 via-surface-900/20 to-transparent" />

          {/* Floating Badges */}
          <div className="absolute top-3 left-3">
            <span className="px-2.5 py-1 bg-surface-900/80 backdrop-blur-md rounded-md text-xs font-semibold text-white border border-white/10">
              Course
            </span>
          </div>

          <div className="absolute bottom-3 right-3">
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-primary-600/90 backdrop-blur-md rounded-md text-xs font-bold text-white shadow-lg">
              <Play className="w-3 h-3 fill-current" />
              <span>{course.videos.length} Episodes</span>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-medium text-primary-400 px-2 py-0.5 bg-primary-400/10 rounded-full">
              {course.skillLevel}
            </span>
            <div className="flex items-center gap-1 text-xs text-surface-400">
              <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
              <span>4.8</span>
            </div>
          </div>

          <h3 className="text-lg font-bold text-white mb-2 line-clamp-1 group-hover:text-primary-400 transition-colors">
            {course.title}
          </h3>

          <p className="text-surface-400 text-sm mb-4 line-clamp-2 leading-relaxed">
            {course.description}
          </p>

          <div className="flex items-center justify-between pt-4 border-t border-surface-700/50">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-surface-700 flex items-center justify-center text-xs font-bold text-surface-300">
                {course.creator[0]}
              </div>
              <span className="text-xs text-surface-300 font-medium">{course.creator}</span>
            </div>

            <div className="flex gap-1">
              {course.tags.slice(0, 2).map(tag => (
                <span key={tag} className="text-[10px] px-1.5 py-0.5 bg-surface-700 rounded text-surface-400">
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Link>
  )
}
