import { Link } from 'react-router-dom'
import { BookOpen, User, LogOut, Upload, List, Zap } from 'lucide-react'

export default function TopBar({ user, onLogout, role }) {
  return (
    <header className="sticky top-0 z-50 bg-surface-900/90 backdrop-blur-lg border-b border-surface-800 shadow-lg">
      <div className="max-w-7xl mx-auto px-6 h-16">
        <div className="flex items-center justify-between h-full">
          {/* Logo */}
          <Link to={role === 'creator' ? '/studio' : '/discover'} className="flex items-center gap-3 group">
            <div className="p-2 bg-primary-500/10 rounded-lg group-hover:bg-primary-500/20 transition-colors">
              <Zap className="w-6 h-6 text-primary-500" />
            </div>
            <span className="text-xl font-bold text-white tracking-tight">
              Skill<span className="text-primary-500">Stream</span>
            </span>
          </Link>

          {/* Navigation */}
          <div className="flex items-center gap-8">
            {role === 'learner' && (
              <nav className="flex items-center gap-6">
                <Link
                  to="/discover"
                  className="flex items-center gap-2 text-sm font-medium text-surface-200 hover:text-primary-500 transition-colors"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Discover</span>
                </Link>
                <Link
                  to="/library"
                  className="flex items-center gap-2 text-sm font-medium text-surface-200 hover:text-primary-500 transition-colors"
                >
                  <List className="w-4 h-4" />
                  <span>Library</span>
                </Link>
              </nav>
            )}

            {role === 'creator' && (
              <Link
                to="/studio"
                className="flex items-center gap-2 text-sm font-medium text-surface-200 hover:text-primary-500 transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span>Studio</span>
              </Link>
            )}

            {/* User Profile */}
            <div className="flex items-center gap-4 pl-6 border-l border-surface-800">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-surface-800 flex items-center justify-center border border-surface-700">
                  <User className="w-4 h-4 text-surface-200" />
                </div>
                <span className="text-sm font-medium text-surface-200">{user?.name}</span>
              </div>
              <button
                onClick={onLogout}
                className="p-2 text-surface-400 hover:text-secondary-500 hover:bg-secondary-500/10 rounded-lg transition-all"
                title="Sign Out"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
