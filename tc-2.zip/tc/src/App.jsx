import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import Welcome from './pages/Welcome'
import Discover from './pages/Discover'
import Studio from './pages/Studio'
import Library from './pages/Library'
import CourseReader from './pages/CourseReader'
import './App.css'

function Application() {
  const [activeSession, setActiveSession] = useState(null)
  const [accountType, setAccountType] = useState(null)

  useEffect(() => {
    // Load session from storage
    const storedSession = localStorage.getItem('skillstream_session')
    const storedType = localStorage.getItem('skillstream_type')
    if (storedSession) {
      setActiveSession(JSON.parse(storedSession))
      setAccountType(storedType)
    }
  }, [])

  const initiateSession = (type) => {
    const newSession = {
      uid: Date.now(),
      displayName: type === 'student' ? 'Alex Student' : 'Sarah Instructor',
      contact: type === 'student' ? 'alex@skillstream.com' : 'sarah@skillstream.com',
    }
    setActiveSession(newSession)
    setAccountType(type)
    localStorage.setItem('skillstream_session', JSON.stringify(newSession))
    localStorage.setItem('skillstream_type', type)
  }

  const terminateSession = () => {
    setActiveSession(null)
    setAccountType(null)
    localStorage.removeItem('skillstream_session')
    localStorage.removeItem('skillstream_type')
  }

  return (
    <Router>
      <Routes>
        <Route 
          path="/" 
          element={
            activeSession ? (
              <Navigate to={accountType === 'instructor' ? '/studio' : '/discover'} replace />
            ) : (
              <Welcome onSignIn={initiateSession} />
            )
          } 
        />
        <Route 
          path="/discover" 
          element={
            activeSession && accountType === 'student' ? (
              <Discover session={activeSession} onSignOut={terminateSession} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/studio" 
          element={
            activeSession && accountType === 'instructor' ? (
              <Studio session={activeSession} onSignOut={terminateSession} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/library" 
          element={
            activeSession && accountType === 'student' ? (
              <Library session={activeSession} onSignOut={terminateSession} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/learn/:id" 
          element={
            activeSession && accountType === 'student' ? (
              <CourseReader session={activeSession} onSignOut={terminateSession} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
      </Routes>
    </Router>
  )
}

export default Application

