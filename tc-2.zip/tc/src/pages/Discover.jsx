import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Search, Sparkles, Filter, Compass } from 'lucide-react'
import { getVideos, updateVideo, getMicroCourses } from '../utils/storage'
import MediaPreview from '../components/MediaPreview'
import CourseTile from '../components/CourseTile'
import TopBar from '../components/TopBar'
import StreamPlayer from '../components/StreamPlayer'

export default function Discover({ session, onSignOut }) {
  const [content, setContent] = useState({ videos: [], courses: [] })
  const [activeFilter, setActiveFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [viewingVideo, setViewingVideo] = useState(null)

  useEffect(() => {
    setContent({
      videos: getVideos(),
      courses: getMicroCourses()
    })
  }, [])

  const handleInteraction = (id, type) => {
    if (type === 'like') {
      const video = content.videos.find(v => v.id === id)
      if (video) {
        updateVideo(id, {
          likes: video.likes + (video.liked ? -1 : 1),
          liked: !video.liked
        })
        setContent(prev => ({ ...prev, videos: getVideos() }))
      }
    } else if (type === 'view') {
      const video = content.videos.find(v => v.id === id)
      if (video) {
        updateVideo(id, { views: (video.views || 0) + 1 })
        setContent(prev => ({ ...prev, videos: getVideos() }))
        setViewingVideo(video)
      }
    }
  }

  const filteredContent = content.videos.filter(video => {
    const matchesFilter = activeFilter === 'all' ||
      video.topic.toLowerCase() === activeFilter.toLowerCase()

    const matchesSearch = !searchQuery ||
      video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      video.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))

    return matchesFilter && matchesSearch
  })

  const categories = ['all', ...new Set(content.videos.map(v => v.topic))]

  return (
    <div className="min-h-screen bg-surface-900 text-white pb-20">
      <TopBar user={session} onLogout={onSignOut} role="learner" />

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Hero Header */}
        <div className="relative mb-12 p-8 rounded-3xl bg-gradient-to-r from-primary-900/50 to-secondary-900/50 border border-white/5 overflow-hidden">
          <div className="absolute top-0 right-0 p-12 opacity-10">
            <Compass className="w-64 h-64" />
          </div>
          <div className="relative z-10">
            <h1 className="text-4xl font-bold mb-4">
              Welcome back, {session.displayName.split(' ')[0]}
            </h1>
            <p className="text-surface-300 text-lg max-w-xl">
              Your daily feed is ready. We've curated some fresh content to help you master <span className="text-primary-400 font-semibold">Web Development</span> today.
            </p>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="sticky top-20 z-40 bg-surface-900/95 backdrop-blur-xl py-4 mb-8 -mx-6 px-6 border-b border-surface-800">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-surface-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Find skills, creators, or topics..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-surface-800 border border-surface-700 rounded-xl focus:outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all text-sm"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveFilter(cat)}
                  className={`px-5 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${activeFilter === cat
                      ? 'bg-primary-600 text-white shadow-lg shadow-primary-900/20'
                      : 'bg-surface-800 text-surface-400 hover:bg-surface-700 hover:text-white'
                    }`}
                >
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Featured Courses */}
        {content.courses.length > 0 && (
          <section className="mb-16">
            <div className="flex items-center gap-2 mb-6">
              <Sparkles className="w-5 h-5 text-secondary-500" />
              <h2 className="text-xl font-bold">Trending Courses</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {content.courses.slice(0, 3).map((course, i) => (
                <motion.div
                  key={course.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <CourseTile course={course} />
                </motion.div>
              ))}
            </div>
          </section>
        )}

        {/* Video Feed */}
        <section>
          <h2 className="text-xl font-bold mb-6">Fresh Drops</h2>
          {filteredContent.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredContent.map((video, i) => (
                <motion.div
                  key={video.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <MediaPreview
                    video={video}
                    onLike={() => handleInteraction(video.id, 'like')}
                    onView={() => handleInteraction(video.id, 'view')}
                  />
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-32 border-2 border-dashed border-surface-800 rounded-3xl">
              <p className="text-surface-500">No content matches your search.</p>
            </div>
          )}
        </section>

        {/* Player Modal */}
        {viewingVideo && (
          <StreamPlayer
            video={viewingVideo}
            onClose={() => setViewingVideo(null)}
            autoPlay={true}
          />
        )}
      </div>
    </div>
  )
}
