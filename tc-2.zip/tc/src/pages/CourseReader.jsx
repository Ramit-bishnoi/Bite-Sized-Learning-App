import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, Play, Check, Lock, Award } from 'lucide-react'
import { getMicroCourseById, updateUserProgress, getUserProgress, getVideoById } from '../utils/storage'
import TopBar from '../components/TopBar'
import StreamPlayer from '../components/StreamPlayer'

export default function CourseReader({ session, onSignOut }) {
  const { id } = useParams()
  const [course, setCourse] = useState(null)
  const [modules, setModules] = useState([])
  const [progress, setProgress] = useState({})
  const [activeLesson, setActiveLesson] = useState(null)

  useEffect(() => {
    const data = getMicroCourseById(id)
    if (data) {
      setCourse(data)
      setModules(data.videos.map(vid => getVideoById(vid)).filter(Boolean))
      const userProg = getUserProgress(session.uid)
      setProgress(userProg[data.id] || {})
    }
  }, [id, session.uid])

  const handleComplete = (videoId) => {
    const newProg = updateUserProgress(session.uid, course.id, videoId, true)
    setProgress(newProg[course.id] || {})
  }

  if (!course) return <div className="min-h-screen bg-surface-900" />

  const completedCount = Object.values(progress).filter(p => p.completed).length
  const percentComplete = Math.round((completedCount / modules.length) * 100)

  return (
    <div className="min-h-screen bg-surface-900 text-white">
      <TopBar user={session} onLogout={onSignOut} role="learner" />

      <div className="max-w-7xl mx-auto px-6 py-8">
        <Link to="/discover" className="inline-flex items-center gap-2 text-surface-400 hover:text-white mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Feed</span>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="relative aspect-video rounded-2xl overflow-hidden mb-8 shadow-2xl">
              <img src={course.thumbnail} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-8">
                <span className="text-primary-400 font-bold tracking-wider text-sm uppercase mb-2">Micro-Course</span>
                <h1 className="text-4xl font-bold mb-2">{course.title}</h1>
                <p className="text-surface-300 max-w-2xl">{course.description}</p>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-bold mb-4">Curriculum</h2>
              {modules.map((module, idx) => {
                const isCompleted = progress[module.id]?.completed
                const isLocked = idx > 0 && !progress[modules[idx - 1].id]?.completed

                return (
                  <div
                    key={module.id}
                    onClick={() => !isLocked && setActiveLesson(module)}
                    className={`group flex items-center gap-4 p-4 rounded-xl border transition-all ${isLocked
                        ? 'bg-surface-900 border-surface-800 opacity-50 cursor-not-allowed'
                        : 'bg-surface-800 border-surface-700 hover:border-primary-500/50 cursor-pointer'
                      }`}
                  >
                    <div className="w-12 h-12 rounded-full bg-surface-900 flex items-center justify-center flex-shrink-0 border border-surface-700">
                      {isCompleted ? (
                        <Check className="w-5 h-5 text-green-500" />
                      ) : isLocked ? (
                        <Lock className="w-5 h-5 text-surface-600" />
                      ) : (
                        <span className="font-bold text-surface-400">{idx + 1}</span>
                      )}
                    </div>

                    <div className="flex-1">
                      <h3 className="font-semibold mb-0.5 group-hover:text-primary-400 transition-colors">{module.title}</h3>
                      <p className="text-sm text-surface-400">{module.duration}s • Video Lesson</p>
                    </div>

                    <div className="px-4 py-2 rounded-lg bg-surface-900 text-sm font-medium text-surface-300 group-hover:bg-primary-600 group-hover:text-white transition-colors">
                      {isCompleted ? 'Replay' : 'Start'}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-surface-800 p-6 rounded-2xl border border-surface-700 sticky top-24">
              <h3 className="font-bold mb-4">Your Progress</h3>
              <div className="w-full bg-surface-900 h-3 rounded-full overflow-hidden mb-4">
                <div
                  className="bg-primary-500 h-full transition-all duration-1000 ease-out"
                  style={{ width: `${percentComplete}%` }}
                />
              </div>
              <div className="flex justify-between text-sm text-surface-400 mb-6">
                <span>{percentComplete}% Complete</span>
                <span>{completedCount}/{modules.length} Steps</span>
              </div>

              {percentComplete === 100 && (
                <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4 flex items-center gap-3 mb-6">
                  <Award className="w-8 h-8 text-green-500" />
                  <div>
                    <p className="font-bold text-green-400">Course Completed!</p>
                    <p className="text-xs text-green-500/80">You've mastered this skill.</p>
                  </div>
                </div>
              )}

              <div className="space-y-4 pt-6 border-t border-surface-700">
                <div className="flex justify-between text-sm">
                  <span className="text-surface-400">Instructor</span>
                  <span className="font-medium">{course.creator}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-surface-400">Level</span>
                  <span className="font-medium">{course.skillLevel}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-surface-400">Last Updated</span>
                  <span className="font-medium">Today</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {activeLesson && (
        <StreamPlayer
          video={activeLesson}
          onClose={() => setActiveLesson(null)}
          onComplete={() => handleComplete(activeLesson.id)}
          isCompleted={progress[activeLesson.id]?.completed}
          autoPlay={true}
        />
      )}
    </div>
  )
}
