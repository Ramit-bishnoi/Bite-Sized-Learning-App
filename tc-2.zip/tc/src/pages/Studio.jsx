import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Upload, Plus, Video, BarChart2, Layers, X } from 'lucide-react'
import { saveVideo, getVideos, saveMicroCourse, getMicroCourses } from '../utils/storage'
import TopBar from '../components/TopBar'

export default function Studio({ session, onSignOut }) {
  const [activeModal, setActiveModal] = useState(null)
  const [content, setContent] = useState({ videos: [], courses: [] })

  useEffect(() => {
    refreshContent()
  }, [])

  const refreshContent = () => {
    const allVideos = getVideos()
    const allCourses = getMicroCourses()
    setContent({
      videos: allVideos.filter(v => v.creatorId === session.uid || !v.creatorId),
      courses: allCourses.filter(c => c.creatorId === session.uid || !c.creatorId)
    })
  }

  const totalViews = content.videos.reduce((acc, v) => acc + (v.views || 0), 0)

  return (
    <div className="min-h-screen bg-surface-900 text-white">
      <TopBar user={session} onLogout={onSignOut} role="creator" />

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Dashboard Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <h1 className="text-3xl font-bold mb-2">Creator Studio</h1>
            <p className="text-surface-400">Manage your content and analytics</p>
          </div>

          <div className="flex gap-4">
            <button
              onClick={() => setActiveModal('upload')}
              className="px-6 py-3 bg-primary-600 hover:bg-primary-500 text-white rounded-xl font-semibold flex items-center gap-2 transition-all shadow-lg shadow-primary-900/20"
            >
              <Upload className="w-5 h-5" />
              <span>Upload Video</span>
            </button>
            <button
              onClick={() => setActiveModal('course')}
              className="px-6 py-3 bg-surface-800 hover:bg-surface-700 text-white rounded-xl font-semibold flex items-center gap-2 border border-surface-700 transition-all"
            >
              <Plus className="w-5 h-5" />
              <span>New Course</span>
            </button>
          </div>
        </div>

        {/* Analytics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <AnalyticsCard
            icon={<Video className="w-6 h-6 text-blue-400" />}
            label="Total Videos"
            value={content.videos.length}
            trend="+12% this week"
          />
          <AnalyticsCard
            icon={<BarChart2 className="w-6 h-6 text-green-400" />}
            label="Total Views"
            value={totalViews.toLocaleString()}
            trend="+24% this week"
          />
          <AnalyticsCard
            icon={<Layers className="w-6 h-6 text-purple-400" />}
            label="Active Courses"
            value={content.courses.length}
            trend="Just updated"
          />
        </div>

        {/* Content Tabs */}
        <div className="space-y-12">
          <section>
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Video className="w-5 h-5 text-surface-400" />
              Recent Uploads
            </h2>
            {content.videos.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {content.videos.map(video => (
                  <div key={video.id} className="bg-surface-800 rounded-xl p-4 border border-surface-700 hover:border-primary-500/30 transition-all">
                    <div className="aspect-video bg-surface-900 rounded-lg mb-4 overflow-hidden relative group">
                      <img src={video.thumbnail} alt="" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="text-sm font-medium">Edit Video</span>
                      </div>
                    </div>
                    <h3 className="font-semibold mb-1 line-clamp-1">{video.title}</h3>
                    <div className="flex justify-between text-sm text-surface-400">
                      <span>{video.views || 0} views</span>
                      <span>{new Date(video.id).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState message="No videos uploaded yet" />
            )}
          </section>

          <section>
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Layers className="w-5 h-5 text-surface-400" />
              Your Courses
            </h2>
            {content.courses.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {content.courses.map(course => (
                  <div key={course.id} className="bg-surface-800 rounded-xl p-6 border border-surface-700 flex gap-6">
                    <div className="w-32 h-24 bg-surface-900 rounded-lg flex-shrink-0 overflow-hidden">
                      <img src={course.thumbnail} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-2">{course.title}</h3>
                      <p className="text-surface-400 text-sm line-clamp-2 mb-3">{course.description}</p>
                      <span className="text-xs font-medium px-2 py-1 bg-surface-700 rounded text-surface-300">
                        {course.videos.length} episodes
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState message="No courses created yet" />
            )}
          </section>
        </div>
      </div>

      {/* Modals */}
      {activeModal === 'upload' && (
        <UploadModal
          onClose={() => setActiveModal(null)}
          onSuccess={() => {
            refreshContent()
            setActiveModal(null)
          }}
          user={session}
        />
      )}

      {activeModal === 'course' && (
        <CourseModal
          onClose={() => setActiveModal(null)}
          onSuccess={() => {
            refreshContent()
            setActiveModal(null)
          }}
          user={session}
          videos={content.videos}
        />
      )}
    </div>
  )
}

function AnalyticsCard({ icon, label, value, trend }) {
  return (
    <div className="bg-surface-800 p-6 rounded-2xl border border-surface-700">
      <div className="flex items-start justify-between mb-4">
        <div className="p-3 bg-surface-900 rounded-xl border border-surface-700">
          {icon}
        </div>
        <span className="text-xs font-medium text-green-400 bg-green-400/10 px-2 py-1 rounded-full">
          {trend}
        </span>
      </div>
      <div className="text-3xl font-bold mb-1">{value}</div>
      <div className="text-sm text-surface-400">{label}</div>
    </div>
  )
}

function EmptyState({ message }) {
  return (
    <div className="w-full py-16 border-2 border-dashed border-surface-800 rounded-2xl flex items-center justify-center text-surface-500">
      {message}
    </div>
  )
}

function UploadModal({ onClose, onSuccess, user }) {
  const [form, setForm] = useState({
    title: '',
    description: '',
    duration: 60,
    topic: 'Web Development',
    skillLevel: 'Beginner',
    tags: '',
    videoUrl: '',
    thumbnail: ''
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    saveVideo({
      ...form,
      id: Date.now(),
      tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
      creator: user.displayName,
      creatorId: user.uid,
      thumbnail: form.thumbnail || `https://via.placeholder.com/400x600/4f46e5/ffffff?text=${encodeURIComponent(form.title)}`
    })
    onSuccess()
  }

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-surface-900 w-full max-w-2xl rounded-2xl border border-surface-700 shadow-2xl overflow-hidden"
      >
        <div className="p-6 border-b border-surface-800 flex justify-between items-center">
          <h2 className="text-xl font-bold">Upload Content</h2>
          <button onClick={onClose}><X className="w-6 h-6 text-surface-400" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-medium text-surface-300 mb-1.5">Title</label>
              <input
                required
                className="w-full bg-surface-800 border border-surface-700 rounded-lg px-4 py-2.5 focus:border-primary-500 focus:outline-none transition-colors"
                value={form.title}
                onChange={e => setForm({ ...form, title: e.target.value })}
              />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-surface-300 mb-1.5">Description</label>
              <textarea
                required
                rows={3}
                className="w-full bg-surface-800 border border-surface-700 rounded-lg px-4 py-2.5 focus:border-primary-500 focus:outline-none transition-colors"
                value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-surface-300 mb-1.5">Topic</label>
              <select
                className="w-full bg-surface-800 border border-surface-700 rounded-lg px-4 py-2.5 focus:border-primary-500 focus:outline-none"
                value={form.topic}
                onChange={e => setForm({ ...form, topic: e.target.value })}
              >
                {['Web Development', 'Design', 'Business', 'Marketing', 'Lifestyle'].map(t => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-surface-300 mb-1.5">Level</label>
              <select
                className="w-full bg-surface-800 border border-surface-700 rounded-lg px-4 py-2.5 focus:border-primary-500 focus:outline-none"
                value={form.skillLevel}
                onChange={e => setForm({ ...form, skillLevel: e.target.value })}
              >
                {['Beginner', 'Intermediate', 'Advanced'].map(l => (
                  <option key={l}>{l}</option>
                ))}
              </select>
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-surface-300 mb-1.5">Video URL</label>
              <input
                type="url"
                className="w-full bg-surface-800 border border-surface-700 rounded-lg px-4 py-2.5 focus:border-primary-500 focus:outline-none"
                value={form.videoUrl}
                onChange={e => setForm({ ...form, videoUrl: e.target.value })}
                placeholder="https://..."
              />
            </div>
          </div>

          <div className="pt-4 flex gap-3">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-3 bg-surface-800 hover:bg-surface-700 rounded-xl font-medium transition-colors">Cancel</button>
            <button type="submit" className="flex-1 px-4 py-3 bg-primary-600 hover:bg-primary-500 rounded-xl font-medium text-white transition-colors">Publish Video</button>
          </div>
        </form>
      </motion.div>
    </div>
  )
}

function CourseModal({ onClose, onSuccess, user, videos }) {
  const [form, setForm] = useState({
    title: '',
    description: '',
    selectedVideos: [],
    skillLevel: 'Beginner',
    thumbnail: ''
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    if (form.selectedVideos.length === 0) return

    saveMicroCourse({
      ...form,
      id: Date.now(),
      tags: ['Course'], // Simplified for demo
      creator: user.displayName,
      creatorId: user.uid,
      videos: form.selectedVideos,
      thumbnail: form.thumbnail || 'https://via.placeholder.com/800x600/4f46e5/ffffff?text=Course'
    })
    onSuccess()
  }

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-surface-900 w-full max-w-2xl rounded-2xl border border-surface-700 shadow-2xl overflow-hidden"
      >
        <div className="p-6 border-b border-surface-800 flex justify-between items-center">
          <h2 className="text-xl font-bold">Create Course</h2>
          <button onClick={onClose}><X className="w-6 h-6 text-surface-400" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          <div>
            <label className="block text-sm font-medium text-surface-300 mb-1.5">Course Title</label>
            <input
              required
              className="w-full bg-surface-800 border border-surface-700 rounded-lg px-4 py-2.5 focus:border-primary-500 focus:outline-none"
              value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-surface-300 mb-1.5">Select Episodes</label>
            <div className="bg-surface-800 border border-surface-700 rounded-lg p-2 max-h-48 overflow-y-auto space-y-1">
              {videos.map(v => (
                <label key={v.id} className="flex items-center gap-3 p-2 hover:bg-surface-700 rounded cursor-pointer">
                  <input
                    type="checkbox"
                    className="rounded border-surface-600 text-primary-600 focus:ring-primary-500 bg-surface-900"
                    checked={form.selectedVideos.includes(v.id)}
                    onChange={() => {
                      const newSelection = form.selectedVideos.includes(v.id)
                        ? form.selectedVideos.filter(id => id !== v.id)
                        : [...form.selectedVideos, v.id]
                      setForm({ ...form, selectedVideos: newSelection })
                    }}
                  />
                  <span className="text-sm">{v.title}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="pt-4 flex gap-3">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-3 bg-surface-800 hover:bg-surface-700 rounded-xl font-medium transition-colors">Cancel</button>
            <button type="submit" className="flex-1 px-4 py-3 bg-primary-600 hover:bg-primary-500 rounded-xl font-medium text-white transition-colors">Create Course</button>
          </div>
        </form>
      </motion.div>
    </div>
  )
}
