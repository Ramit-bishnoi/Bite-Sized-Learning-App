import { motion } from 'framer-motion'
import { BookOpen, Zap, TrendingUp, Users, ArrowRight } from 'lucide-react'

export default function Welcome({ onSignIn }) {
  return (
    <div className="min-h-screen bg-surface-900 text-white selection:bg-primary-500/30">
      {/* Navigation */}
      <nav className="px-6 py-6 flex justify-between items-center max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-primary-500/10 rounded-lg">
            <Zap className="w-6 h-6 text-primary-500" />
          </div>
          <span className="text-xl font-bold tracking-tight">SkillStream</span>
        </div>
        <div className="text-sm font-medium text-surface-400">
          Master skills in minutes
        </div>
      </nav>

      {/* Hero Section */}
      <main className="container mx-auto px-6 pt-20 pb-32">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight tracking-tight">
              Micro-Learning for the
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-400 via-secondary-500 to-primary-600">
                Modern Creator
              </span>
            </h1>

            <p className="text-xl text-surface-300 mb-12 max-w-2xl mx-auto leading-relaxed">
              Ditch the hour-long lectures. Stream bite-sized knowledge from world-class experts and level up your skills while you wait for your coffee.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onSignIn('student')}
                className="px-8 py-4 bg-primary-600 hover:bg-primary-500 text-white rounded-xl font-semibold text-lg shadow-xl shadow-primary-900/20 transition-all flex items-center gap-2 group"
              >
                Start Watching
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onSignIn('instructor')}
                className="px-8 py-4 bg-surface-800 hover:bg-surface-700 text-white rounded-xl font-semibold text-lg border border-surface-700 transition-all"
              >
                Share Knowledge
              </motion.button>
            </div>
          </motion.div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mt-32">
          <FeatureCard
            icon={<Zap className="w-6 h-6" />}
            title="Lightning Fast"
            description="30-90 second lessons that get straight to the point. No fluff, just value."
          />
          <FeatureCard
            icon={<TrendingUp className="w-6 h-6" />}
            title="Smart Feed"
            description="Our AI curates a personalized learning path based on your goals and interests."
          />
          <FeatureCard
            icon={<Users className="w-6 h-6" />}
            title="Community Driven"
            description="Join a thriving community of learners and creators sharing real-world skills."
          />
        </div>
      </main>
    </div>
  )
}

function FeatureCard({ icon, title, description }) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="p-8 bg-surface-800/50 backdrop-blur-sm rounded-2xl border border-surface-700/50 hover:border-primary-500/30 transition-all group"
    >
      <div className="w-12 h-12 bg-surface-800 rounded-xl flex items-center justify-center mb-6 text-primary-500 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3 text-white">{title}</h3>
      <p className="text-surface-400 leading-relaxed">{description}</p>
    </motion.div>
  )
}
