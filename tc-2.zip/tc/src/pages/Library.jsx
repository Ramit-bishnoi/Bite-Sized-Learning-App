import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Plus, Folder, Trash2, Play, MoreVertical } from 'lucide-react'
import { getPlaylists, savePlaylist, updatePlaylist, getVideos } from '../utils/storage'
import TopBar from '../components/TopBar'

export default function Library({ session, onSignOut }) {
  const [playlists, setPlaylists] = useState([])
  const [activeModal, setActiveModal] = useState(null)
  const [selectedList, setSelectedList] = useState(null)

  useEffect(() => {
    loadContent()
  }, [])

  const loadContent = () => {
    setPlaylists(getPlaylists())
  }

  const createPlaylist = (name) => {
    savePlaylist({
      name,
      description: '',
      userId: session.uid,
      videoIds: []
    })
    loadContent()
    setActiveModal(null)
  }

  return (
    <div className="min-h-screen bg-surface-900 text-white">
      <TopBar user={session} onLogout={onSignOut} role="learner" />

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">My Library</h1>
          <button
            onClick={() => setActiveModal('create')}
            className="px-5 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl font-medium flex items-center gap-2 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>New Collection</span>
          </button>
        </div>

        {playlists.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {playlists.map(list => (
              <PlaylistCard
                key={list.id}
                playlist={list}
                onClick={() => setSelectedList(list)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 border-2 border-dashed border-surface-800 rounded-2xl">
            <Folder className="w-16 h-16 text-surface-600 mx-auto mb-4" />
            <p className="text-surface-400">Your library is empty.</p>
          </div>
        )}
      </div>

      {activeModal === 'create' && (
        <CreateModal onClose={() => setActiveModal(null)} onCreate={createPlaylist} />
      )}

      {selectedList && (
        <DetailModal
          playlist={selectedList}
          onClose={() => setSelectedList(null)}
          onUpdate={loadContent}
        />
      )}
    </div>
  )
}

function PlaylistCard({ playlist, onClick }) {
  const videoCount = playlist.videoIds?.length || 0

  return (
    <motion.div
      whileHover={{ y: -4 }}
      onClick={onClick}
      className="bg-surface-800 rounded-xl overflow-hidden border border-surface-700 hover:border-primary-500/30 cursor-pointer group"
    >
      <div className="h-32 bg-surface-700 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-900/40 to-secondary-900/40" />
        <div className="absolute bottom-4 left-4">
          <Folder className="w-8 h-8 text-white/80" />
        </div>
      </div>
      <div className="p-5">
        <h3 className="font-bold text-lg mb-1">{playlist.name}</h3>
        <p className="text-sm text-surface-400">{videoCount} items</p>
      </div>
    </motion.div>
  )
}

function CreateModal({ onClose, onCreate }) {
  const [name, setName] = useState('')
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-surface-900 p-6 rounded-2xl border border-surface-700 w-full max-w-md">
        <h2 className="text-xl font-bold mb-4">New Collection</h2>
        <input
          autoFocus
          className="w-full bg-surface-800 border border-surface-700 rounded-lg px-4 py-2.5 mb-6 focus:border-primary-500 focus:outline-none"
          placeholder="Collection Name"
          value={name}
          onChange={e => setName(e.target.value)}
        />
        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 bg-surface-800 rounded-lg hover:bg-surface-700 transition-colors">Cancel</button>
          <button onClick={() => onCreate(name)} className="flex-1 py-2.5 bg-primary-600 text-white rounded-lg hover:bg-primary-500 transition-colors">Create</button>
        </div>
      </div>
    </div>
  )
}

function DetailModal({ playlist, onClose, onUpdate }) {
  const [videos, setVideos] = useState([])

  useEffect(() => {
    const all = getVideos()
    setVideos(all.filter(v => playlist.videoIds?.includes(v.id)))
  }, [playlist])

  const removeVideo = (id) => {
    const updated = {
      ...playlist,
      videoIds: playlist.videoIds.filter(vid => vid !== id)
    }
    updatePlaylist(playlist.id, updated)
    onUpdate()
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-surface-900 p-6 rounded-2xl border border-surface-700 w-full max-w-2xl max-h-[80vh] flex flex-col">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">{playlist.name}</h2>
          <button onClick={onClose}><div className="p-2 hover:bg-surface-800 rounded-lg">✕</div></button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3">
          {videos.length > 0 ? videos.map(v => (
            <div key={v.id} className="flex items-center gap-4 p-3 bg-surface-800 rounded-lg group">
              <img src={v.thumbnail} className="w-16 h-12 object-cover rounded" />
              <div className="flex-1 min-w-0">
                <h4 className="font-medium truncate">{v.title}</h4>
                <p className="text-xs text-surface-400">{v.duration}s</p>
              </div>
              <button
                onClick={() => removeVideo(v.id)}
                className="p-2 text-surface-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          )) : (
            <p className="text-center text-surface-500 py-8">This collection is empty.</p>
          )}
        </div>
      </div>
    </div>
  )
}
