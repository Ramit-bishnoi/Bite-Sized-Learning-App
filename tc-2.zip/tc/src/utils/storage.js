// Utility functions for localStorage management

export const saveVideo = (video) => {
  const videos = getVideos()
  const newVideo = {
    ...video,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    views: 0,
    likes: 0,
    comments: []
  }
  videos.push(newVideo)
  localStorage.setItem('videos', JSON.stringify(videos))
  return newVideo
}

export const getVideos = () => {
  const videos = localStorage.getItem('videos')
  return videos ? JSON.parse(videos) : getDefaultVideos()
}

export const getVideoById = (id) => {
  const videos = getVideos()
  return videos.find(v => v.id === id)
}

export const updateVideo = (id, updates) => {
  const videos = getVideos()
  const index = videos.findIndex(v => v.id === id)
  if (index !== -1) {
    videos[index] = { ...videos[index], ...updates }
    localStorage.setItem('videos', JSON.stringify(videos))
    return videos[index]
  }
  return null
}

export const saveMicroCourse = (course) => {
  const courses = getMicroCourses()
  const newCourse = {
    ...course,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    enrolledUsers: [],
    progress: {}
  }
  courses.push(newCourse)
  localStorage.setItem('microCourses', JSON.stringify(courses))
  return newCourse
}

export const getMicroCourses = () => {
  const courses = localStorage.getItem('microCourses')
  return courses ? JSON.parse(courses) : getDefaultMicroCourses()
}

export const getMicroCourseById = (id) => {
  const courses = getMicroCourses()
  return courses.find(c => c.id === id)
}

export const savePlaylist = (playlist) => {
  const playlists = getPlaylists()
  const newPlaylist = {
    ...playlist,
    id: Date.now().toString(),
    createdAt: new Date().toISOString()
  }
  playlists.push(newPlaylist)
  localStorage.setItem('playlists', JSON.stringify(playlists))
  return newPlaylist
}

export const getPlaylists = () => {
  const playlists = localStorage.getItem('playlists')
  return playlists ? JSON.parse(playlists) : []
}

export const updatePlaylist = (id, updates) => {
  const playlists = getPlaylists()
  const index = playlists.findIndex(p => p.id === id)
  if (index !== -1) {
    playlists[index] = { ...playlists[index], ...updates }
    localStorage.setItem('playlists', JSON.stringify(playlists))
    return playlists[index]
  }
  return null
}

export const getUserProgress = (userId) => {
  const progress = localStorage.getItem(`progress_${userId}`)
  return progress ? JSON.parse(progress) : {}
}

export const updateUserProgress = (userId, courseId, videoId, completed) => {
  const progress = getUserProgress(userId)
  if (!progress[courseId]) {
    progress[courseId] = {}
  }
  progress[courseId][videoId] = {
    completed,
    completedAt: completed ? new Date().toISOString() : null
  }
  localStorage.setItem(`progress_${userId}`, JSON.stringify(progress))
  return progress
}

// Default mock data
function getDefaultVideos() {
  return [
    {
      id: '1',
      title: 'Introduction to React Hooks',
      description: 'Learn the basics of useState and useEffect in 60 seconds',
      creator: 'Sarah Instructor',
      creatorId: 'creator1',
      duration: 60,
      thumbnail: 'https://via.placeholder.com/400x600/6366f1/ffffff?text=React+Hooks',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      tags: ['React', 'JavaScript', 'Frontend', 'Beginner'],
      topic: 'Web Development',
      skillLevel: 'Beginner',
      views: 1250,
      likes: 89,
      comments: [],
      createdAt: new Date(Date.now() - 86400000).toISOString()
    },
    {
      id: '2',
      title: 'Python List Comprehensions',
      description: 'Master list comprehensions in Python with practical examples',
      creator: 'Python Pro',
      creatorId: 'creator2',
      duration: 75,
      thumbnail: 'https://via.placeholder.com/400x600/8b5cf6/ffffff?text=Python',
      videoUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_2mb.mp4',
      tags: ['Python', 'Programming', 'Intermediate'],
      topic: 'Programming',
      skillLevel: 'Intermediate',
      views: 890,
      likes: 67,
      comments: [],
      createdAt: new Date(Date.now() - 172800000).toISOString()
    },
    {
      id: '3',
      title: 'CSS Grid Layout Basics',
      description: 'Create responsive layouts with CSS Grid in under a minute',
      creator: 'Design Expert',
      creatorId: 'creator3',
      duration: 55,
      thumbnail: 'https://via.placeholder.com/400x600/ec4899/ffffff?text=CSS+Grid',
      videoUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_5mb.mp4',
      tags: ['CSS', 'Web Design', 'Frontend', 'Beginner'],
      topic: 'Web Development',
      skillLevel: 'Beginner',
      views: 2100,
      likes: 156,
      comments: [],
      createdAt: new Date(Date.now() - 3600000).toISOString()
    },
    {
      id: '4',
      title: 'Async/Await Explained',
      description: 'Understanding async/await in JavaScript',
      creator: 'Sarah Instructor',
      creatorId: 'creator1',
      duration: 65,
      thumbnail: 'https://via.placeholder.com/400x600/14b8a6/ffffff?text=Async+Await',
      videoUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_10mb.mp4',
      tags: ['JavaScript', 'Async', 'Programming', 'Intermediate'],
      topic: 'Web Development',
      skillLevel: 'Intermediate',
      views: 980,
      likes: 72,
      comments: [],
      createdAt: new Date(Date.now() - 7200000).toISOString()
    }
  ]
}

function getDefaultMicroCourses() {
  return [
    {
      id: 'course1',
      title: 'React Fundamentals in 5 Minutes',
      description: 'A quick journey through React basics',
      creator: 'Sarah Instructor',
      creatorId: 'creator1',
      videos: ['1', '4'],
      tags: ['React', 'JavaScript', 'Web Development'],
      skillLevel: 'Beginner',
      thumbnail: 'https://via.placeholder.com/400x600/6366f1/ffffff?text=React+Fundamentals',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
      enrolledUsers: [],
      progress: {}
    }
  ]
}

