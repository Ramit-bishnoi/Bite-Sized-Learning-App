# LearnBite - Bite-Sized Learning App

A modern, Instagram-style learning platform where educators can upload short educational videos (30-90 seconds) and learners can consume knowledge in bite-sized, addictive formats.

## 🚀 Features

### For Learners
- **Personalized AI-based Learning Feed**: Scroll through educational content tailored to your interests
- **Learning Playlists**: Organize videos into custom playlists for structured learning
- **Micro-Courses**: Complete short courses made of multiple bite-sized videos
- **Progress Tracking**: Track your learning progress with visual indicators
- **AI-Generated Summaries & Quizzes**: Get instant feedback and practice questions

### For Creators
- **Upload Educational Reels**: Share 30-90 second educational videos
- **Tagging System**: Tag topics, concepts, and skill levels for better discoverability
- **Micro-Course Creation**: Build structured courses from multiple short videos
- **Analytics Dashboard**: Track views, likes, and engagement

## 🛠️ Tech Stack

- **React 18** - Modern UI framework
- **Vite** - Fast build tool and dev server
- **React Router** - Client-side routing
- **Tailwind CSS** - Utility-first styling
- **Framer Motion** - Smooth animations
- **Lucide React** - Beautiful icons
- **LocalStorage** - Client-side data persistence (prototype)

## 📦 Installation & Running in VS Code

### Quick Start (3 Steps)

1. **Open in VS Code**
   - Open Visual Studio Code
   - File → Open Folder → Select the `tc` folder

2. **Install Dependencies**
   - Open terminal in VS Code: Press `` Ctrl + ` `` (backtick)
   - Run: `npm install`

3. **Start the Server**
   - Run: `npm run dev`
   - Browser will open automatically at `http://localhost:3000`

### Detailed VS Code Setup

📖 **See [VSCODE_SETUP.md](./VSCODE_SETUP.md) for complete step-by-step instructions with troubleshooting**

### Manual Installation

1. Clone the repository or navigate to the project directory

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser to `http://localhost:3000`

## 🎯 Usage

### As a Learner

1. **Start Learning**: Click "Start Learning" on the landing page
2. **Browse Feed**: Scroll through personalized educational content
3. **Search & Filter**: Use the search bar and topic filters to find specific content
4. **Create Playlists**: Organize videos into learning playlists
5. **Take Courses**: Enroll in micro-courses and track your progress

### As a Creator

1. **Become a Creator**: Click "Become a Creator" on the landing page
2. **Upload Videos**: Use the dashboard to upload new educational videos
3. **Tag Content**: Add tags, topics, and skill levels to your videos
4. **Create Courses**: Combine multiple videos into structured micro-courses

## 🎨 Design Philosophy

- **Addictive Simplicity**: Inspired by Instagram/TikTok's engaging UX
- **Dark Mode First**: Modern dark theme for comfortable learning
- **Mobile-First**: Responsive design that works on all devices
- **Micro-Learning**: Bite-sized content that respects users' time

## 📝 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── Navbar.jsx
│   └── VideoCard.jsx
├── pages/              # Main page components
│   ├── Landing.jsx
│   ├── LearnerFeed.jsx
│   ├── CreatorDashboard.jsx
│   ├── Playlists.jsx
│   └── MicroCourseView.jsx
├── utils/              # Utility functions
│   └── storage.js      # LocalStorage management
├── App.jsx            # Main app component
├── main.jsx           # App entry point
└── index.css          # Global styles
```

## 🔮 Future Enhancements

- Real video playback integration
- Backend API with database
- User authentication system
- AI-powered content recommendations
- Social features (comments, follows, shares)
- Monetization features
- Advanced analytics for creators

## 📄 License

This is a prototype project created for educational purposes.

## 🙏 Credits

Built as a working prototype for a bite-sized learning platform concept. All design and implementation by the development team.

